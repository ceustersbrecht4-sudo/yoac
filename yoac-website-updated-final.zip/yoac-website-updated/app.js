// ===================== YOAC - YOUR ONLINE AI COACH =====================
// A browser port of the desktop app's core feature: live camera pose
// tracking with rep counting and coaching tips. Runs entirely in the
// browser - the camera and the AI model never leave the device, there is
// no server and no upload.

import {
  PoseLandmarker,
  FilesetResolver,
} from "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14";

// ---- MediaPipe pose landmark indices (standard BlazePose topology) ----
const PL = {
  LEFT_SHOULDER: 11, RIGHT_SHOULDER: 12,
  LEFT_ELBOW: 13, RIGHT_ELBOW: 14,
  LEFT_WRIST: 15, RIGHT_WRIST: 16,
  LEFT_HIP: 23, RIGHT_HIP: 24,
  LEFT_KNEE: 25, RIGHT_KNEE: 26,
  LEFT_ANKLE: 27, RIGHT_ANKLE: 28,
  LEFT_FOOT_INDEX: 31, RIGHT_FOOT_INDEX: 32,
};

// ---- Muscle group colors (ported from the desktop app's palette) ----
const GROUP_COLORS = {
  "Legs": "#ff9500",
  "Chest": "#eb453a",
  "Arms & Shoulders": "#2882e6",
  "Back": "#a05ac8",
  "Core": "#28b2aa",
};
const MUSCLE_GROUPS = ["Legs", "Chest", "Arms & Shoulders", "Back", "Core"];
const ACCENT = "#14d26e";

// ---- Exercise library (ported 1:1 from the desktop app's EXERCISES dict)
const EXERCISES = {
  "1": { type: "compound", name: "Squats", group: "Legs", joints: ["HIP", "KNEE", "ANKLE"],
    down: 100, up: 160, downLabel: "DEEP SQUAT", midLabel: "BENDING", upLabel: "STANDING",
    secJoints: ["SHOULDER", "HIP", "KNEE"], secLabel: "Hip" },
  "2": { type: "compound", name: "Lunges", group: "Legs", joints: ["HIP", "KNEE", "ANKLE"],
    down: 100, up: 160, downLabel: "LUNGE DOWN", midLabel: "BENDING", upLabel: "STANDING",
    secJoints: ["SHOULDER", "HIP", "KNEE"], secLabel: "Hip" },
  "3": { type: "isolation", name: "Leg Extension", group: "Legs", joints: ["HIP", "KNEE", "ANKLE"],
    down: 100, up: 160, downLabel: "BENT", midLabel: "EXTENDING", upLabel: "EXTENDED",
    secJoints: null, secLabel: null },
  "4": { type: "isolation", name: "Leg Curl", group: "Legs", joints: ["HIP", "KNEE", "ANKLE"],
    down: 90, up: 160, downLabel: "CURLED", midLabel: "CURLING", upLabel: "EXTENDED",
    secJoints: ["SHOULDER", "HIP", "KNEE"], secLabel: "Hip" },
  "5": { type: "isolation", name: "Calf Raise", group: "Legs", joints: ["KNEE", "ANKLE", "FOOT_INDEX"],
    down: 100, up: 130, downLabel: "HEELS DOWN", midLabel: "RISING", upLabel: "RAISED",
    secJoints: ["HIP", "KNEE", "ANKLE"], secLabel: "Knee" },
  "6": { type: "compound", name: "Push-ups", group: "Chest", framing: "full_body", joints: ["SHOULDER", "ELBOW", "WRIST"],
    down: 110, up: 150, downLabel: "DOWN", midLabel: "LOWERING", upLabel: "UP",
    secJoints: ["SHOULDER", "HIP", "KNEE"], secLabel: "Body line" },
  "7": { type: "isolation", name: "Bicep Curl", group: "Arms & Shoulders", framing: "upper_body", joints: ["SHOULDER", "ELBOW", "WRIST"],
    down: 60, up: 150, downLabel: "CURLED", midLabel: "MOVING", upLabel: "EXTENDED",
    secJoints: ["ELBOW", "SHOULDER", "HIP"], secLabel: "Shoulder" },
  "8": { type: "compound", name: "Shoulder Press", group: "Arms & Shoulders", framing: "upper_body", joints: ["SHOULDER", "ELBOW", "WRIST"],
    down: 100, up: 160, downLabel: "LOWERED", midLabel: "PRESSING", upLabel: "PRESSED UP",
    secJoints: ["SHOULDER", "HIP", "KNEE"], secLabel: "Torso lean" },
  "9": { type: "compound", name: "Lat Pulldown", group: "Back", framing: "upper_body", joints: ["SHOULDER", "ELBOW", "WRIST"],
    down: 70, up: 150, downLabel: "PULLED DOWN", midLabel: "MOVING", upLabel: "EXTENDED",
    secJoints: ["SHOULDER", "HIP", "KNEE"], secLabel: "Torso lean" },
  "10": { type: "isolation", name: "Tricep Pushdown", group: "Arms & Shoulders", framing: "upper_body", joints: ["SHOULDER", "ELBOW", "WRIST"],
    down: 70, up: 160, downLabel: "EXTENDED", midLabel: "MOVING", upLabel: "BENT",
    secJoints: ["ELBOW", "SHOULDER", "HIP"], secLabel: "Shoulder" },
  "11": { type: "compound", name: "Seated Row", group: "Back", framing: "upper_body", joints: ["SHOULDER", "ELBOW", "WRIST"],
    down: 70, up: 150, downLabel: "PULLED", midLabel: "MOVING", upLabel: "EXTENDED",
    secJoints: ["SHOULDER", "HIP", "KNEE"], secLabel: "Torso lean" },
  "12": { type: "compound", name: "Bench Press", group: "Chest", framing: "upper_body", joints: ["SHOULDER", "ELBOW", "WRIST"],
    down: 100, up: 160, downLabel: "LOWERED", midLabel: "PRESSING", upLabel: "PRESSED UP",
    secJoints: null, secLabel: null },
  "13": { type: "compound", name: "Pull-ups", group: "Back", framing: "full_body", joints: ["SHOULDER", "ELBOW", "WRIST"],
    down: 70, up: 160, downLabel: "PULLED UP", midLabel: "MOVING", upLabel: "HANGING",
    secJoints: ["SHOULDER", "HIP", "KNEE"], secLabel: "Body swing" },
  "14": { type: "isolation", name: "Chest Fly", group: "Chest", joints: ["ELBOW", "SHOULDER", "HIP"],
    down: 30, up: 80, downLabel: "TOGETHER", midLabel: "MOVING", upLabel: "OPEN",
    secJoints: ["SHOULDER", "ELBOW", "WRIST"], secLabel: "Elbow bend" },
  "15": { type: "isolation", name: "Crunches", group: "Core", joints: ["SHOULDER", "HIP", "KNEE"],
    down: 80, up: 140, downLabel: "CURLED", midLabel: "MOVING", upLabel: "LYING BACK",
    secJoints: ["HIP", "KNEE", "ANKLE"], secLabel: "Knee" },
  "16": { type: "compound", name: "Deadlift", group: "Back", joints: ["SHOULDER", "HIP", "KNEE"],
    down: 90, up: 160, downLabel: "HINGED DOWN", midLabel: "MOVING", upLabel: "STANDING",
    secJoints: ["HIP", "KNEE", "ANKLE"], secLabel: "Knee" },
  "17": { name: "Spin Pass", group: "Rugby", framing: "upper_body", joints: ["SHOULDER", "ELBOW", "WRIST"],
    down: 70, up: 160, downLabel: "LOADED", midLabel: "PASSING", upLabel: "RELEASED",
    secJoints: ["HIP", "SHOULDER", "ELBOW"], secLabel: "Pass arm" },
  "18": { name: "Place Kick", group: "Rugby", joints: ["HIP", "KNEE", "ANKLE"],
    down: 90, up: 165, downLabel: "WIND UP", midLabel: "SWINGING", upLabel: "FOLLOW THROUGH",
    secJoints: ["SHOULDER", "HIP", "KNEE"], secLabel: "Torso lean" },
  "19": { name: "Shooting Technique", group: "Football", joints: ["HIP", "KNEE", "ANKLE"],
    down: 90, up: 165, downLabel: "WIND UP", midLabel: "SWINGING", upLabel: "FOLLOW THROUGH",
    secJoints: ["SHOULDER", "HIP", "KNEE"], secLabel: "Torso lean" },
  "20": { name: "Knee Drive", group: "Football", joints: ["HIP", "KNEE", "ANKLE"],
    down: 90, up: 160, downLabel: "KNEE UP", midLabel: "DRIVING", upLabel: "EXTENDED",
    secJoints: null, secLabel: null },
  "21": { name: "Full Swing (Drive)", group: "Golf", framing: "upper_body", joints: ["SHOULDER", "ELBOW", "WRIST"],
    down: 130, up: 165, downLabel: "BACKSWING", midLabel: "SWINGING", upLabel: "FOLLOW THROUGH",
    secJoints: null, secLabel: null },
  "22": { name: "Putt", group: "Golf", framing: "upper_body", joints: ["SHOULDER", "ELBOW", "WRIST"],
    down: 150, up: 175, downLabel: "BACKSTROKE", midLabel: "STROKING", upLabel: "FOLLOW THROUGH",
    secJoints: null, secLabel: null },
  "23": { name: "Chip Shot", group: "Golf", framing: "upper_body", joints: ["SHOULDER", "ELBOW", "WRIST"],
    down: 148, up: 174, downLabel: "SHORT BACKSWING", midLabel: "CHIPPING", upLabel: "FOLLOW THROUGH",
    secJoints: null, secLabel: null },
  "24": { name: "Pitch Shot", group: "Golf", framing: "upper_body", joints: ["SHOULDER", "ELBOW", "WRIST"],
    down: 140, up: 170, downLabel: "BACKSWING", midLabel: "PITCHING", upLabel: "FOLLOW THROUGH",
    secJoints: null, secLabel: null },
  "25": { name: "Approach Shot (Iron)", group: "Golf", framing: "upper_body", joints: ["SHOULDER", "ELBOW", "WRIST"],
    down: 135, up: 168, downLabel: "BACKSWING", midLabel: "SWINGING", upLabel: "FOLLOW THROUGH",
    secJoints: null, secLabel: null },
  "26": { name: "Bunker Shot", group: "Golf", framing: "upper_body", joints: ["SHOULDER", "ELBOW", "WRIST"],
    down: 138, up: 170, downLabel: "BACKSWING", midLabel: "SWINGING", upLabel: "FOLLOW THROUGH",
    secJoints: null, secLabel: null },
};

const SPORTS = ["Rugby", "Football", "Golf"];
const SPORT_COLORS = { "Rugby": "#1e6e3c", "Football": "#38bdf8", "Golf": "#a3e635" };

const FOOD_CATEGORIES = ["Meat & Fish", "Dairy & Eggs", "Carbs & Grains", "Vegetables", "Fruits", "Legumes", "Fats & Nuts", "Other"];

const FOOD_CATEGORY_COLORS = {
  "Meat & Fish": "#eb453a",
  "Dairy & Eggs": "#ebd2d2",
  "Carbs & Grains": "#ff9500",
  "Vegetables": "#3cbe5a",
  "Fruits": "#dc3c8c",
  "Legumes": "#96823c",
  "Fats & Nuts": "#be821e",
  "Other": "#969696"
};

const FOOD_DATABASE = {
  "Chicken breast (100g)": { cal: 165, protein: 31, carbs: 0, fat: 3.6, category: "Meat & Fish" },
  "Chicken thigh (100g)": { cal: 209, protein: 26, carbs: 0, fat: 10.9, category: "Meat & Fish" },
  "Salmon (100g)": { cal: 208, protein: 20, carbs: 0, fat: 13, category: "Meat & Fish", note: "High in vitamin D and omega-3" },
  "Lean beef (100g)": { cal: 217, protein: 26, carbs: 0, fat: 12, category: "Meat & Fish", note: "High in iron" },
  "Ground turkey (100g)": { cal: 176, protein: 22, carbs: 0, fat: 9, category: "Meat & Fish" },
  "Pork chop (100g)": { cal: 231, protein: 25, carbs: 0, fat: 14, category: "Meat & Fish" },
  "Tuna, canned (100g)": { cal: 132, protein: 29, carbs: 0, fat: 1, category: "Meat & Fish" },
  "Shrimp (100g)": { cal: 99, protein: 24, carbs: 0.2, fat: 0.3, category: "Meat & Fish" },
  "Bacon (2 slices)": { cal: 90, protein: 6, carbs: 0.3, fat: 7, category: "Meat & Fish" },
  "Eggs (2 large)": { cal: 156, protein: 12.6, carbs: 1.1, fat: 10.6, category: "Dairy & Eggs" },
  "Greek yogurt (170g)": { cal: 100, protein: 17, carbs: 6, fat: 0.7, category: "Dairy & Eggs", note: "High in calcium" },
  "Cottage cheese (100g)": { cal: 98, protein: 11, carbs: 3.4, fat: 4.3, category: "Dairy & Eggs", note: "High in calcium" },
  "Whey protein (1 scoop)": { cal: 120, protein: 24, carbs: 3, fat: 1.5, category: "Dairy & Eggs" },
  "Milk, whole (1 cup)": { cal: 149, protein: 7.7, carbs: 12, fat: 8, category: "Dairy & Eggs", note: "High in calcium" },
  "Milk, skim (1 cup)": { cal: 83, protein: 8.3, carbs: 12, fat: 0.2, category: "Dairy & Eggs", note: "High in calcium" },
  "Cheddar cheese (28g)": { cal: 113, protein: 7, carbs: 0.4, fat: 9.3, category: "Dairy & Eggs", note: "High in calcium" },
  "Mozzarella (28g)": { cal: 85, protein: 6.3, carbs: 0.6, fat: 6.3, category: "Dairy & Eggs", note: "High in calcium" },
  "White rice, cooked (1 cup)": { cal: 205, protein: 4.3, carbs: 45, fat: 0.4, category: "Carbs & Grains" },
  "Brown rice, cooked (1 cup)": { cal: 216, protein: 5, carbs: 45, fat: 1.8, category: "Carbs & Grains" },
  "Oats, dry (100g)": { cal: 389, protein: 17, carbs: 66, fat: 7, category: "Carbs & Grains" },
  "Whole wheat bread (1 slice)": { cal: 81, protein: 4, carbs: 14, fat: 1.1, category: "Carbs & Grains" },
  "White bread (1 slice)": { cal: 75, protein: 2.6, carbs: 14, fat: 1, category: "Carbs & Grains" },
  "Sweet potato (1 medium)": { cal: 112, protein: 2, carbs: 26, fat: 0.1, category: "Carbs & Grains", note: "High in vitamin A" },
  "Potato, baked (1 medium)": { cal: 161, protein: 4.3, carbs: 37, fat: 0.2, category: "Carbs & Grains" },
  "Pasta, cooked (1 cup)": { cal: 221, protein: 8.1, carbs: 43, fat: 1.3, category: "Carbs & Grains" },
  "Quinoa, cooked (1 cup)": { cal: 222, protein: 8, carbs: 39, fat: 3.6, category: "Carbs & Grains" },
  "Tortilla, flour (1 medium)": { cal: 146, protein: 4, carbs: 24, fat: 3.7, category: "Carbs & Grains" },
  "Spinach, raw (100g)": { cal: 23, protein: 2.9, carbs: 3.6, fat: 0.4, category: "Vegetables", note: "High in iron and vitamin A" },
  "Broccoli, cooked (1 cup)": { cal: 55, protein: 3.7, carbs: 11, fat: 0.6, category: "Vegetables", note: "High in vitamin C" },
  "Carrots, raw (1 cup)": { cal: 52, protein: 1.2, carbs: 12, fat: 0.3, category: "Vegetables", note: "High in vitamin A" },
  "Bell pepper (1 medium)": { cal: 24, protein: 1, carbs: 6, fat: 0.2, category: "Vegetables", note: "High in vitamin C" },
  "Tomato (1 medium)": { cal: 22, protein: 1.1, carbs: 4.8, fat: 0.2, category: "Vegetables" },
  "Cucumber (1 cup)": { cal: 16, protein: 0.7, carbs: 3.8, fat: 0.1, category: "Vegetables" },
  "Cauliflower, cooked (1 cup)": { cal: 29, protein: 2.3, carbs: 5.3, fat: 0.6, category: "Vegetables", note: "High in vitamin C" },
  "Green beans, cooked (1 cup)": { cal: 44, protein: 2.4, carbs: 10, fat: 0.4, category: "Vegetables" },
  "Banana (1 medium)": { cal: 105, protein: 1.3, carbs: 27, fat: 0.4, category: "Fruits" },
  "Apple (1 medium)": { cal: 95, protein: 0.5, carbs: 25, fat: 0.3, category: "Fruits" },
  "Orange (1 medium)": { cal: 62, protein: 1.2, carbs: 15, fat: 0.2, category: "Fruits", note: "High in vitamin C" },
  "Strawberries (1 cup)": { cal: 49, protein: 1, carbs: 12, fat: 0.5, category: "Fruits", note: "High in vitamin C" },
  "Blueberries (1 cup)": { cal: 84, protein: 1.1, carbs: 21, fat: 0.5, category: "Fruits" },
  "Grapes (1 cup)": { cal: 104, protein: 1.1, carbs: 27, fat: 0.2, category: "Fruits" },
  "Mango (1 cup)": { cal: 99, protein: 1.4, carbs: 25, fat: 0.6, category: "Fruits", note: "High in vitamin C" },
  "Pineapple (1 cup)": { cal: 82, protein: 0.9, carbs: 22, fat: 0.2, category: "Fruits", note: "High in vitamin C" },
  "Black beans, cooked (1 cup)": { cal: 227, protein: 15, carbs: 41, fat: 0.9, category: "Legumes" },
  "Chickpeas, cooked (1 cup)": { cal: 269, protein: 15, carbs: 45, fat: 4.3, category: "Legumes" },
  "Lentils, cooked (1 cup)": { cal: 230, protein: 18, carbs: 40, fat: 0.8, category: "Legumes", note: "High in iron" },
  "Kidney beans, cooked (1 cup)": { cal: 225, protein: 15, carbs: 40, fat: 0.9, category: "Legumes" },
  "Tofu (100g)": { cal: 76, protein: 8, carbs: 1.9, fat: 4.8, category: "Legumes" },
  "Edamame, cooked (1 cup)": { cal: 189, protein: 17, carbs: 16, fat: 8, category: "Legumes" },
  "Avocado (1 medium)": { cal: 234, protein: 2.9, carbs: 12, fat: 21, category: "Fats & Nuts" },
  "Almonds (28g / small handful)": { cal: 164, protein: 6, carbs: 6, fat: 14, category: "Fats & Nuts" },
  "Walnuts (28g / small handful)": { cal: 185, protein: 4.3, carbs: 3.9, fat: 18.5, category: "Fats & Nuts" },
  "Peanut butter (2 tbsp)": { cal: 188, protein: 8, carbs: 6, fat: 16, category: "Fats & Nuts" },
  "Olive oil (1 tbsp)": { cal: 119, protein: 0, carbs: 0, fat: 13.5, category: "Fats & Nuts" },
  "Chia seeds (1 tbsp)": { cal: 58, protein: 2, carbs: 5, fat: 3.7, category: "Fats & Nuts" },
  "Protein bar (1 bar)": { cal: 200, protein: 20, carbs: 22, fat: 7, category: "Other" },
  "Pizza slice (1 slice)": { cal: 285, protein: 12, carbs: 36, fat: 10, category: "Other" },
  "Dark chocolate (28g)": { cal: 155, protein: 1.4, carbs: 13, fat: 11, category: "Other" },
  "Protein shake, ready-made (1 bottle)": { cal: 160, protein: 30, carbs: 5, fat: 3, category: "Other" },
};


// ---- Parse the serving size out of a food name like "Chicken breast (100g)"
// or "Eggs (2 large)", so amounts can be scaled precisely instead of being
// locked to the default serving. ----
function parseServing(name) {
  const m = name.match(/\(([^)]+)\)\s*$/);
  if (!m) return { amount: 1, unit: "serving", isGrams: false };
  const inner = m[1];
  const numMatch = inner.match(/^([\d.]+)\s*(.*)$/);
  if (!numMatch) return { amount: 1, unit: inner, isGrams: false };
  const amount = parseFloat(numMatch[1]);
  let unit = numMatch[2].trim();
  const isGrams = unit === "g" || /^g[\s/]/.test(unit);
  if (isGrams) unit = "g";
  return { amount, unit: unit || "serving", isGrams };
}

// ---- Coaching-tip rules (ported from TIP_RULES) ----
const TIP_RULES = {
  "Hip": { low: 130, tipLow: "Keep your chest up - you're leaning too far forward" },
  "Body line": { low: 160, high: 200,
    tipLow: "Your hips are sagging - engage your core to flatten your back",
    tipHigh: "Your hips are piked up too high - lower them into a straight line" },
  "Body swing": { low: 155, high: 205,
    tipLow: "Try to keep your legs from swinging forward",
    tipHigh: "Try to keep your legs from swinging backward" },
  "Shoulder": { high: 35, tipHigh: "Keep your upper arm still - you're swinging your shoulder" },
  "Torso lean": { low: 145, tipLow: "Keep your torso more upright - you're leaning back too far" },
  "Knee": { low: 160, tipLow: "Try to keep that knee straighter" },
  "Elbow bend": { low: 130, high: 175,
    tipLow: "Keep a bit more bend in your elbow", tipHigh: "Don't lock your elbow out completely" },
  "Pass arm": { low: 60, tipLow: "Swing the pass across your body, not down and up" },
};

function getFormTip(secLabel, angle) {
  const rule = TIP_RULES[secLabel];
  if (!rule) return [null, true];
  if (rule.low !== undefined && angle < rule.low) return [rule.tipLow, false];
  if (rule.high !== undefined && angle > rule.high) return [rule.tipHigh, false];
  return [null, true];
}

// ---- Geometry ----
function calcAngle(a, b, c) {
  const ang = Math.abs(
    Math.atan2(c.y - b.y, c.x - b.x) - Math.atan2(a.y - b.y, a.x - b.x)
  ) * (180 / Math.PI);
  return ang > 180 ? 360 - ang : ang;
}

function sideJoints(exercise, side) {
  return exercise.joints.map((name) => PL[`${side}_${name}`]);
}

// ===================== APP / SCREEN MANAGEMENT =====================
const root = document.getElementById("app");
let currentGroup = null;
let currentBackFn = null;
let pointsData = null;
let stream = null;
let poseLandmarker = null;
let trackingLoopId = null;

function el(tag, className, text) {
  const e = document.createElement(tag);
  if (className) e.className = className;
  if (text !== undefined) e.textContent = text;
  return e;
}

function clearRoot() {
  if (trackingLoopId) {
    cancelAnimationFrame(trackingLoopId);
    trackingLoopId = null;
  }
  if (stream) {
    stream.getTracks().forEach((t) => t.stop());
    stream = null;
  }
  root.innerHTML = "";
}

const BADGE_SRC = "assets/yoac-app-icon-dark.png";
const WORDMARK_SRC = "assets/yoac-wordmark-bold.png";

function header(container, title, subtitle) {
  const h = el("div", "header");
  const badge = el("div", "badge");
  badge.innerHTML = `<img src="${BADGE_SRC}" alt="YOAC" style="width:100%;height:100%;object-fit:contain;border-radius:20%;"/>`;
  const titles = el("div");
  titles.appendChild(el("div", "title", "YOAC"));
  titles.appendChild(el("div", "subtitle", subtitle));
  h.appendChild(badge);
  h.appendChild(titles);
  container.appendChild(h);
  container.appendChild(el("div", "underline"));
}

function card(label, colorHex, iconSvg, onClick) {
  const c = el("div", "card");
  const chip = el("div", "chip");
  chip.style.background = colorHex;
  chip.innerHTML = iconSvg;
  c.appendChild(chip);
  c.appendChild(el("div", "card-label", label));
  c.addEventListener("click", onClick);
  return c;
}

const ICONS = {
  dumbbell: `<svg viewBox="0 0 24 24"><rect x="2" y="9" width="5" height="6" rx="1" fill="#161616"/><rect x="17" y="9" width="5" height="6" rx="1" fill="#161616"/><line x1="7" y1="12" x2="17" y2="12" stroke="#161616" stroke-width="2.5"/></svg>`,
  back: `<svg viewBox="0 0 24 24"><path d="M15 5 L8 12 L15 19" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/></svg>`,
  apple: `<svg viewBox="0 0 24 24"><path d="M12 8c-3 0-5 2.2-5 5.5S9 21 12 21s5-3.2 5-7.5S15 8 12 8z" fill="#161616"/><path d="M12 8 L13 5" stroke="#161616" stroke-width="1.5" fill="none" stroke-linecap="round"/><path d="M13 5 Q16 4 16.5 6.5 Q14 7 13 5z" fill="#161616"/></svg>`,
};

// ---- Local profile (stored only in this browser - not a shared account) ----
function loadProfile() {
  try { return JSON.parse(localStorage.getItem("aiFormChecker_profile")); }
  catch { return null; }
}
function saveProfile(p) { localStorage.setItem("aiFormChecker_profile", JSON.stringify(p)); }

function showWelcome() {
  clearRoot();
  const c = el("div", "screen welcome-screen");
  const logo = el("div", "welcome-logo");
  logo.innerHTML = `<img src="${WORDMARK_SRC}" alt="YOAC - Your Online AI Coach"/>`;
  c.appendChild(logo);
  const blurb = el("div", "welcome-blurb");
  blurb.innerHTML = "Point your phone or laptop camera at yourself and get live rep counting and coaching tips for gym exercises and sport-specific drills - all running right in your browser. Nothing is uploaded anywhere; your camera feed never leaves this device.";
  c.appendChild(blurb);
  const startBtn = el("button", "start-btn", "Get Started");
  startBtn.addEventListener("click", () => {
    const existing = loadProfile();
    if (existing) showTopMenu();
    else showProfileSetup();
  });
  c.appendChild(startBtn);
  root.appendChild(c);
}

// ---- Screen: profile setup / edit ----
function showProfileSetup(isEdit) {
  clearRoot();
  const existing = loadProfile() || {};
  const c = el("div", "screen profile-screen");
  header(c, isEdit ? "EDIT PROFILE" : "SET UP YOUR PROFILE", "Saved only on this device - never uploaded anywhere");

  const form = el("div", "profile-form");

  const nameField = el("div", "profile-field");
  nameField.appendChild(el("label", "profile-label", "Name"));
  const nameInput = el("input", "profile-input");
  nameInput.type = "text"; nameInput.placeholder = "Your name"; nameInput.value = existing.name || "";
  nameField.appendChild(nameInput);
  form.appendChild(nameField);

  const ageField = el("div", "profile-field");
  ageField.appendChild(el("label", "profile-label", "Age"));
  const ageInput = el("input", "profile-input");
  ageInput.type = "number"; ageInput.min = "13"; ageInput.max = "100"; ageInput.placeholder = "Age"; ageInput.value = existing.age || "";
  ageField.appendChild(ageInput);
  form.appendChild(ageField);

  const weightField = el("div", "profile-field");
  weightField.appendChild(el("label", "profile-label", "Weight (kg)"));
  const weightInput = el("input", "profile-input");
  weightInput.type = "number"; weightInput.min = "20"; weightInput.step = "0.5"; weightInput.placeholder = "Weight"; weightInput.value = existing.weight || "";
  weightField.appendChild(weightInput);
  form.appendChild(weightField);

  const genderField = el("div", "profile-field");
  genderField.appendChild(el("label", "profile-label", "Gender"));
  const genderRow = el("div", "gender-row");
  const genderOptions = ["Female", "Male", "Other", "Prefer not to say"];
  let selectedGender = existing.gender || null;
  const genderBtns = genderOptions.map((g) => {
    const btn = el("button", "gender-btn" + (selectedGender === g ? " gender-btn-selected" : ""), g);
    btn.type = "button";
    btn.addEventListener("click", () => {
      selectedGender = g;
      genderBtns.forEach((b) => b.classList.remove("gender-btn-selected"));
      btn.classList.add("gender-btn-selected");
    });
    genderRow.appendChild(btn);
    return btn;
  });
  genderField.appendChild(genderRow);
  form.appendChild(genderField);

  c.appendChild(form);

  const errorMsg = el("div", "profile-error");
  c.appendChild(errorMsg);

  const saveBtn = el("button", "start-btn", isEdit ? "Save changes" : "Create profile");
  saveBtn.addEventListener("click", () => {
    const name = nameInput.value.trim();
    if (!name) { errorMsg.textContent = "Please enter a name."; return; }
    const profile = {
      name,
      age: ageInput.value ? Number(ageInput.value) : null,
      weight: weightInput.value ? Number(weightInput.value) : null,
      gender: selectedGender,
    };
    saveProfile(profile);
    showTopMenu();
  });
  c.appendChild(saveBtn);

  if (isEdit) {
    const backCard = card("Back", "#2a2a2a", ICONS.back, showTopMenu);
    backCard.classList.add("back-card", "single-back");
    c.appendChild(backCard);
  } else {
    const skipBtn = el("button", "start-btn schedule-add-btn", "Skip for now");
    skipBtn.addEventListener("click", showTopMenu);
    c.appendChild(skipBtn);
  }

  root.appendChild(c);
}

// ---- Screen: top-level menu ----
function showTopMenu() {
  clearRoot();
  const profile = loadProfile();
  const c = el("div", "screen");
  header(c, "YOAC", profile ? `Welcome back, ${profile.name}` : "What do you want to do?");

  const ptsBadge = el("div", "points-badge", `${pointsData.totalPoints} pts`);
  c.appendChild(ptsBadge);
  if (pointsData.loginStreak > 1) {
    c.appendChild(el("div", "points-streak", `${pointsData.loginStreak}-day streak`));
  }

  const grid = el("div", "grid");
  grid.appendChild(card("Exercises", "#2882e6", ICONS.dumbbell, showExercisesHub));
  grid.appendChild(card("Sports", SPORT_COLORS.Rugby, ICONS.dumbbell, showSportsHub));
  grid.appendChild(card("Nutrition log", "#f5c518", ICONS.apple, showNutritionLog));
  grid.appendChild(card("Training schedule", "#a05ac8", ICONS.dumbbell, showScheduleHub));
  c.appendChild(grid);

  const profileLink = el("div", "profile-link", profile ? "Edit profile" : "Set up your profile");
  profileLink.addEventListener("click", () => showProfileSetup(!!profile));
  c.appendChild(profileLink);

  const note = el("div", "note", "Runs entirely in your browser - your camera never leaves this device.");
  c.appendChild(note);
  root.appendChild(c);
}

function comingSoonCard(label) {
  const c = el("div", "card card-disabled");
  const chip = el("div", "chip");
  chip.style.background = "#2a2a2a";
  c.appendChild(chip);
  c.appendChild(el("div", "card-label", label));
  c.appendChild(el("div", "soon-tag", "Coming soon"));
  return c;
}

// ---- Screen: Exercises hub (muscle groups + body map) ----
function showExercisesHub() {
  clearRoot();
  const c = el("div", "screen");
  header(c, "EXERCISES", "Choose a muscle group");

  const bodyBtn = el("button", "body-map-btn", "\u{1F9CD} Body map");
  bodyBtn.addEventListener("click", showBodyMap);
  c.appendChild(bodyBtn);

  const grid = el("div", "grid");
  MUSCLE_GROUPS.forEach((g) => {
    grid.appendChild(card(g, GROUP_COLORS[g], ICONS.dumbbell, () => showExerciseList(g, showExercisesHub)));
  });
  const backCard = card("Menu", "#2a2a2a", ICONS.back, showTopMenu);
  backCard.classList.add("back-card");
  grid.appendChild(backCard);
  c.appendChild(grid);
  root.appendChild(c);
}

// ---- Screen: Sports hub ----
function showSportsHub() {
  clearRoot();
  const c = el("div", "screen");
  header(c, "SPORTS", "Pick a sport");
  c.appendChild(el("div", "note note-top", "Checks your technique - not ball contact or accuracy"));
  const grid = el("div", "grid");
  SPORTS.forEach((s) => {
    grid.appendChild(card(s, SPORT_COLORS[s], ICONS.dumbbell, () => showExerciseList(s, showSportsHub)));
  });
  ["Field hockey", "Kickboxing / MMA"].forEach((s) => grid.appendChild(comingSoonCard(s)));
  const backCard = card("Menu", "#2a2a2a", ICONS.back, showTopMenu);
  backCard.classList.add("back-card");
  grid.appendChild(backCard);
  c.appendChild(grid);
  root.appendChild(c);
}

// ---- Screen: clickable body map ----
function showBodyMap() {
  clearRoot();
  const c = el("div", "screen");
  header(c, "BODY MAP", "Tap a muscle group on the figure");

  const wrap = el("div", "bodymap-wrap");
  const regions = [
    { group: "Arms & Shoulders", label: "Arms & Shoulders", path: "M30,35 L44,35 L46,80 L28,80 Z M156,35 L170,35 L172,80 L154,80 Z" },
    { group: "Chest", label: "Chest / Core", path: "M62,35 L138,35 L142,120 L58,120 Z" },
    { group: "Legs", label: "Legs", path: "M58,124 L142,124 L134,270 L108,270 L104,150 L96,150 L92,270 L66,270 Z" },
  ];
  const svgNS = "http://www.w3.org/2000/svg";
  const svg = document.createElementNS(svgNS, "svg");
  svg.setAttribute("viewBox", "0 0 200 290");
  svg.classList.add("bodymap-svg");

  const head = document.createElementNS(svgNS, "circle");
  head.setAttribute("cx", "100"); head.setAttribute("cy", "14"); head.setAttribute("r", "16");
  head.setAttribute("fill", "#3a3a3a");
  svg.appendChild(head);

  regions.forEach((r) => {
    const p = document.createElementNS(svgNS, "path");
    p.setAttribute("d", r.path);
    p.setAttribute("fill", GROUP_COLORS[r.group] + "55");
    p.setAttribute("stroke", GROUP_COLORS[r.group]);
    p.setAttribute("stroke-width", "2");
    p.classList.add("bodymap-region");
    p.addEventListener("click", () => showExerciseList(r.group, showBodyMap));
    p.addEventListener("mouseenter", () => { p.setAttribute("fill", GROUP_COLORS[r.group] + "aa"); });
    p.addEventListener("mouseleave", () => { p.setAttribute("fill", GROUP_COLORS[r.group] + "55"); });
    svg.appendChild(p);
  });
  wrap.appendChild(svg);
  c.appendChild(wrap);

  const legend = el("div", "bodymap-legend");
  regions.forEach((r) => {
    const item = el("div", "legend-item");
    const dot = el("span", "legend-dot");
    dot.style.background = GROUP_COLORS[r.group];
    item.appendChild(dot);
    item.appendChild(el("span", null, r.label));
    item.addEventListener("click", () => showExerciseList(r.group, showBodyMap));
    legend.appendChild(item);
  });
  c.appendChild(legend);

  const backCard = card("Back", "#2a2a2a", ICONS.back, showExercisesHub);
  backCard.classList.add("back-card", "single-back");
  c.appendChild(backCard);

  root.appendChild(c);
}

// ---- Screen: exercise list for a group/sport ----
function showExerciseList(group, backFn) {
  clearRoot();
  currentGroup = group;
  currentBackFn = backFn || showExercisesHub;
  const c = el("div", "screen");
  const color = GROUP_COLORS[group] || SPORT_COLORS[group] || ACCENT;
  header(c, group.toUpperCase(), `${group} exercises`);
  const grid = el("div", "grid");
  Object.entries(EXERCISES)
    .filter(([, ex]) => ex.group === group)
    .forEach(([key, ex]) => {
      grid.appendChild(card(ex.name, color, ICONS.dumbbell, () => startTracking(key)));
    });
  const backCard = card("Back", "#2a2a2a", ICONS.back, currentBackFn);
  backCard.classList.add("back-card");
  grid.appendChild(backCard);
  c.appendChild(grid);
  root.appendChild(c);
}

// ===================== NUTRITION LOG =====================
function loadNutritionLog() {
  try {
    return JSON.parse(localStorage.getItem("nutritionLog") || "{}");
  } catch {
    return {};
  }
}
function saveNutritionLog(log) {
  try {
    localStorage.setItem("nutritionLog", JSON.stringify(log));
  } catch (e) {
    console.warn("Could not save nutrition log:", e);
  }
}
function dayTotals(entries) {
  const t = { cal: 0, protein: 0, carbs: 0, fat: 0 };
  entries.forEach((e) => { t.cal += e.cal; t.protein += e.protein; t.carbs += e.carbs; t.fat += e.fat; });
  return t;
}
function dateOffset(daysAgo) {
  const d = new Date();
  d.setDate(d.getDate() - daysAgo);
  return d.toISOString().slice(0, 10);
}

// ===================== TRAINING SCHEDULE =====================
const PROGRAM_GOALS = {
  "Bigger back": { blurb: "Emphasizes Back, with Legs and Arms & Shoulders for balance.",
    priority: ["Back", "Legs", "Arms & Shoulders", "Chest", "Core"] },
  "Bigger legs": { blurb: "Emphasizes Legs, with Core and upper body for balance.",
    priority: ["Legs", "Legs", "Core", "Back", "Chest"] },
  "Bigger chest & arms": { blurb: "Emphasizes Chest and Arms & Shoulders, with Back for balance.",
    priority: ["Chest", "Arms & Shoulders", "Back", "Legs", "Core"] },
  "General fitness": { blurb: "A balanced full-body rotation across every muscle group.",
    priority: ["Legs", "Chest", "Back", "Arms & Shoulders", "Core"] },
  "Core & abs focus": { blurb: "Emphasizes Core every session, rotating the rest.",
    priority: ["Core", "Legs", "Back", "Chest", "Arms & Shoulders"] },
};

function setsRepsFor(exercise) {
  return exercise.type === "compound" ? "4 x 8" : "3 x 12";
}

function generateProgram(goalName, daysPerWeek) {
  const priority = PROGRAM_GOALS[goalName].priority;
  const byGroup = {};
  Object.entries(EXERCISES).forEach(([key, ex]) => {
    (byGroup[ex.group] = byGroup[ex.group] || []).push([key, ex]);
  });
  const useCount = {}; MUSCLE_GROUPS.forEach((g) => (useCount[g] = 0));
  const days = [];

  for (let dayI = 0; dayI < daysPerWeek; dayI++) {
    const focusGroup = priority[dayI % priority.length];
    const pool = byGroup[focusGroup] || [];
    const offset = pool.length ? useCount[focusGroup] % pool.length : 0;
    let picks = pool.length ? pool.slice(offset).concat(pool.slice(0, offset)).slice(0, 3) : [];
    useCount[focusGroup] += picks.length;

    if (picks.length < 3) {
      for (const otherGroup of priority) {
        if (otherGroup === focusGroup) continue;
        const otherPool = byGroup[otherGroup] || [];
        if (otherPool.length) {
          const idx = useCount[otherGroup] % otherPool.length;
          picks.push(otherPool[idx]);
          useCount[otherGroup] += 1;
          break;
        }
      }
    }

    days.push({
      dayNum: dayI + 1,
      focus: focusGroup,
      exercises: picks.map(([key, ex]) => [key, ex, setsRepsFor(ex)]),
    });
  }
  return days;
}

// ---- localStorage persistence for the manual schedule + points ----
function loadMySchedule() {
  try { return JSON.parse(localStorage.getItem("aiFormChecker_mySchedule")) || { days: [] }; }
  catch { return { days: [] }; }
}
function saveMySchedule(sched) { localStorage.setItem("aiFormChecker_mySchedule", JSON.stringify(sched)); }

function loadPoints() {
  try {
    const p = JSON.parse(localStorage.getItem("aiFormChecker_points"));
    if (p) return { totalPoints: 0, loginStreak: 0, lastLogin: null, exerciseBests: {}, log: [], ...p };
  } catch {}
  return { totalPoints: 0, loginStreak: 0, lastLogin: null, exerciseBests: {}, log: [] };
}
function savePoints(p) { localStorage.setItem("aiFormChecker_points", JSON.stringify(p)); }

const DAILY_LOGIN_BONUS = 10, BASE_SET_POINTS = 25, PR_BONUS = 15;

function applyDailyLoginBonus(points) {
  const today = dateOffset(0);
  if (points.lastLogin === today) return 0;
  points.loginStreak = points.lastLogin === dateOffset(1) ? points.loginStreak + 1 : 1;
  points.lastLogin = today;
  points.totalPoints += DAILY_LOGIN_BONUS;
  savePoints(points);
  return DAILY_LOGIN_BONUS;
}

function computeAndApplyPoints(exercise, reps, weight, points) {
  if (reps <= 0) return { pts: 0, isPr: false };
  let pts = BASE_SET_POINTS;
  let isPr = false;
  if (weight && weight > 0) {
    const prev = points.exerciseBests[exercise.name] || 0;
    if (weight > prev) { isPr = true; points.exerciseBests[exercise.name] = weight; pts += PR_BONUS; }
  }
  points.totalPoints += pts;
  points.log.push({ date: dateOffset(0), exercise: exercise.name, reps, weight: weight || 0, points: pts });
  points.log = points.log.slice(-200);
  savePoints(points);
  return { pts, isPr };
}

// ---- Screen: precise amount entry for a food, before logging it ----
function showFoodAmountEntry(name, food, onDone, onCancel) {
  clearRoot();
  const serving = parseServing(name);
  let amount = serving.amount;

  const c = el("div", "screen");
  header(c, name, `How much did you have?`);

  const stepper = el("div", "weight-stepper");
  const step = serving.isGrams ? (serving.amount >= 100 ? 10 : 5) : (serving.amount <= 2 ? 0.5 : 1);
  const minusBtn = el("button", "weight-step-btn", "\u2212");
  const valueWrap = el("div", "amount-value-wrap");
  const valueInput = el("input", "amount-value-input");
  valueInput.type = "number";
  valueInput.min = "0";
  valueInput.step = String(step);
  valueInput.value = String(amount);
  const unitLabel = el("div", "amount-unit-label", serving.unit);
  valueWrap.appendChild(valueInput);
  valueWrap.appendChild(unitLabel);
  const plusBtn = el("button", "weight-step-btn", "+");
  stepper.appendChild(minusBtn); stepper.appendChild(valueWrap); stepper.appendChild(plusBtn);
  c.appendChild(stepper);

  c.appendChild(el("div", "note", `Default serving: ${serving.amount} ${serving.unit} - ${food.cal} cal, ${food.protein}p / ${food.carbs}c / ${food.fat}f`));

  function clampRead() {
    const v = parseFloat(valueInput.value);
    return isNaN(v) || v < 0 ? 0 : v;
  }
  minusBtn.addEventListener("click", () => { amount = Math.max(0, clampRead() - step); valueInput.value = String(amount); });
  plusBtn.addEventListener("click", () => { amount = clampRead() + step; valueInput.value = String(amount); });
  valueInput.addEventListener("input", () => { amount = clampRead(); });

  const previewBox = el("div", "amount-preview");
  c.appendChild(previewBox);
  function updatePreview() {
    const scale = serving.amount > 0 ? amount / serving.amount : 0;
    previewBox.textContent = `= ${Math.round(food.cal * scale)} cal, ${Math.round(food.protein * scale * 10) / 10}p / ${Math.round(food.carbs * scale * 10) / 10}c / ${Math.round(food.fat * scale * 10) / 10}f`;
  }
  valueInput.addEventListener("input", updatePreview);
  minusBtn.addEventListener("click", updatePreview);
  plusBtn.addEventListener("click", updatePreview);
  updatePreview();

  const addBtn = el("button", "start-btn", "Add to log");
  addBtn.addEventListener("click", () => {
    const scale = serving.amount > 0 ? clampRead() / serving.amount : 0;
    const finalAmount = clampRead();
    const displayName = serving.isGrams
      ? name.replace(/\([^)]+\)\s*$/, `(${finalAmount}g)`)
      : `${name} (x${finalAmount / serving.amount || 0})`;
    onDone({
      food: serving.isGrams ? displayName : name,
      cal: food.cal * scale,
      protein: food.protein * scale,
      carbs: food.carbs * scale,
      fat: food.fat * scale,
    });
  });
  c.appendChild(addBtn);

  const cancelBtn = el("button", "start-btn schedule-add-btn", "Cancel");
  cancelBtn.addEventListener("click", onCancel);
  c.appendChild(cancelBtn);

  root.appendChild(c);
}

function showNutritionLog() {
  clearRoot();
  const log = loadNutritionLog();
  let dayOffset = 0;
  let selectedCategory = null;
  let searchText = "";

  const c = el("div", "screen");
  header(c, "NUTRITION LOG", "Track what you eat");

  const dateRow = el("div", "date-nav");
  const prevBtn = el("button", "date-btn", "<");
  const dateLabel = el("div", "date-label");
  const nextBtn = el("button", "date-btn", ">");
  dateRow.appendChild(prevBtn); dateRow.appendChild(dateLabel); dateRow.appendChild(nextBtn);
  c.appendChild(dateRow);

  const totalsRow = el("div", "totals-row");
  c.appendChild(totalsRow);

  const catRow = el("div", "cat-row");
  c.appendChild(catRow);

  const searchWrap = el("div", "nut-search-wrap");
  const searchInput = el("input", "nut-search-input");
  searchInput.type = "text";
  searchInput.placeholder = "Search foods to add...";
  searchWrap.appendChild(searchInput);
  c.appendChild(searchWrap);
  const resultsBox = el("div", "nut-results");
  c.appendChild(resultsBox);

  const loggedHeader = el("div", "logged-header");
  c.appendChild(loggedHeader);
  const entriesBox = el("div", "nut-entries");
  c.appendChild(entriesBox);

  const backCard = card("Back to menu", "#2a2a2a", ICONS.back, showTopMenu);
  backCard.classList.add("back-card", "single-back");
  c.appendChild(backCard);

  const note = el("div", "note", "Local food database - not a live nutrition API.");
  c.appendChild(note);

  root.appendChild(c);

  function currentDateStr() { return dateOffset(dayOffset); }

  function render() {
    const dateStr = currentDateStr();
    const entries = log[dateStr] || [];
    const totals = dayTotals(entries);

    dateLabel.textContent = dayOffset === 0 ? "Today" : dayOffset === 1 ? "Yesterday" : dateStr;
    nextBtn.disabled = dayOffset === 0;
    prevBtn.disabled = dayOffset >= 13;

    totalsRow.innerHTML = "";
    [["Calories", Math.round(totals.cal)], ["Protein", Math.round(totals.protein) + "g"],
     ["Carbs", Math.round(totals.carbs) + "g"], ["Fat", Math.round(totals.fat) + "g"]].forEach(([label, val]) => {
      const box = el("div", "stat-box");
      box.appendChild(el("div", "stat-val", String(val)));
      box.appendChild(el("div", "stat-label", label));
      totalsRow.appendChild(box);
    });

    catRow.innerHTML = "";
    FOOD_CATEGORIES.forEach((cat) => {
      const chip = el("div", "cat-chip", cat);
      const color = FOOD_CATEGORY_COLORS[cat];
      chip.style.borderColor = color;
      if (selectedCategory === cat) { chip.style.background = color; chip.style.color = "#161616"; }
      chip.addEventListener("click", () => {
        selectedCategory = selectedCategory === cat ? null : cat;
        renderResults();
        render();
      });
      catRow.appendChild(chip);
    });

    loggedHeader.textContent = `Logged today (${entries.length})`;

    entriesBox.innerHTML = "";
    if (entries.length === 0) {
      entriesBox.appendChild(el("div", "note", "Nothing logged yet - search or pick a category below to add food."));
    }
    entries.forEach((e, idx) => {
      const row = el("div", "nut-entry");
      const info = el("div", "nut-entry-info");
      info.innerHTML = `<b>${e.food}</b><br><span class="nut-entry-macros">${Math.round(e.cal)} cal, ${Math.round(e.protein)}p / ${Math.round(e.carbs)}c / ${Math.round(e.fat)}f</span>`;
      const removeBtn = el("button", "nut-remove-btn", "\u2715");
      removeBtn.addEventListener("click", () => {
        entries.splice(idx, 1);
        log[dateStr] = entries;
        saveNutritionLog(log);
        render();
      });
      row.appendChild(info);
      row.appendChild(removeBtn);
      entriesBox.appendChild(row);
    });
  }

  function renderResults() {
    resultsBox.innerHTML = "";
    const text = searchText.trim().toLowerCase();
    let names = Object.keys(FOOD_DATABASE);
    if (selectedCategory) names = names.filter((n) => FOOD_DATABASE[n].category === selectedCategory);
    if (text) names = names.filter((n) => n.toLowerCase().includes(text));
    else if (!selectedCategory) { return; }
    names.slice(0, 8).forEach((name) => {
      const food = FOOD_DATABASE[name];
      const row = el("div", "nut-result");
      const dot = el("span", "nut-dot");
      dot.style.background = FOOD_CATEGORY_COLORS[food.category];
      row.appendChild(dot);
      row.appendChild(el("span", null, `${name} - ${food.cal} cal`));
      row.addEventListener("click", () => {
        showFoodAmountEntry(
          name,
          food,
          (entry) => {
            const dateStr = currentDateStr();
            log[dateStr] = log[dateStr] || [];
            log[dateStr].push(entry);
            saveNutritionLog(log);
            showNutritionLog();
          },
          () => showNutritionLog()
        );
      });
      resultsBox.appendChild(row);
    });
  }

  prevBtn.addEventListener("click", () => { if (dayOffset < 13) { dayOffset++; render(); } });
  nextBtn.addEventListener("click", () => { if (dayOffset > 0) { dayOffset--; render(); } });
  searchInput.addEventListener("input", () => { searchText = searchInput.value; renderResults(); });

  render();
  renderResults();
}

// ---- Screen: Training Schedule hub ----
function showScheduleHub() {
  clearRoot();
  const c = el("div", "screen");
  header(c, "TRAINING SCHEDULE", "AI-built or your own custom plan");
  const grid = el("div", "grid");
  grid.appendChild(card("Build my program", ACCENT, ICONS.dumbbell, showProgramGoalPicker));
  grid.appendChild(card("My own schedule", "#28b2aa", ICONS.dumbbell, showMySchedule));
  const backCard = card("Menu", "#2a2a2a", ICONS.back, showTopMenu);
  backCard.classList.add("back-card");
  grid.appendChild(backCard);
  c.appendChild(grid);
  root.appendChild(c);
}

// ---- Screen: AI program builder - pick a goal ----
function showProgramGoalPicker() {
  clearRoot();
  const c = el("div", "screen");
  header(c, "BUILD MY PROGRAM", "What's your main goal?");
  const list = el("div", "list-col");
  Object.entries(PROGRAM_GOALS).forEach(([name, data]) => {
    const row = el("div", "list-row");
    row.appendChild(el("div", "list-row-title", name));
    row.appendChild(el("div", "list-row-sub", data.blurb));
    row.addEventListener("click", () => showProgramDaysPicker(name));
    list.appendChild(row);
  });
  c.appendChild(list);
  const backCard = card("Back", "#2a2a2a", ICONS.back, showScheduleHub);
  backCard.classList.add("back-card", "single-back");
  c.appendChild(backCard);
  root.appendChild(c);
}

// ---- Screen: AI program builder - pick days per week ----
function showProgramDaysPicker(goalName) {
  clearRoot();
  const c = el("div", "screen");
  header(c, "BUILD MY PROGRAM", `Goal: ${goalName}`);
  const list = el("div", "list-col");
  [2, 3, 4, 5, 6].forEach((n) => {
    const row = el("div", "list-row");
    row.appendChild(el("div", "list-row-title", `${n} days a week`));
    row.addEventListener("click", () => showProgramDisplay(goalName, n));
    list.appendChild(row);
  });
  c.appendChild(list);
  const backCard = card("Back", "#2a2a2a", ICONS.back, showProgramGoalPicker);
  backCard.classList.add("back-card", "single-back");
  c.appendChild(backCard);
  root.appendChild(c);
}

// ---- Screen: AI program builder - the generated program ----
function showProgramDisplay(goalName, daysPerWeek) {
  clearRoot();
  const program = generateProgram(goalName, daysPerWeek);
  let dayIdx = 0;

  const c = el("div", "screen");
  header(c, "YOUR PROGRAM", `${goalName} - ${daysPerWeek} days/week`);

  const dayNav = el("div", "date-nav");
  const prevBtn = el("button", "date-btn", "<");
  const dayLabel = el("div", "date-label");
  const nextBtn = el("button", "date-btn", ">");
  dayNav.appendChild(prevBtn); dayNav.appendChild(dayLabel); dayNav.appendChild(nextBtn);
  c.appendChild(dayNav);

  const listBox = el("div", "list-col");
  c.appendChild(listBox);

  const backCard = card("Back", "#2a2a2a", ICONS.back, () => showProgramDaysPicker(goalName));
  backCard.classList.add("back-card", "single-back");
  c.appendChild(backCard);
  root.appendChild(c);

  function render() {
    const day = program[dayIdx];
    dayLabel.textContent = `Day ${day.dayNum} of ${program.length} - ${day.focus} focus`;
    prevBtn.disabled = dayIdx === 0;
    nextBtn.disabled = dayIdx === program.length - 1;
    listBox.innerHTML = "";
    day.exercises.forEach(([key, ex, sr]) => {
      const row = el("div", "list-row list-row-click");
      row.appendChild(el("div", "list-row-title", ex.name));
      row.appendChild(el("div", "list-row-sub", `${sr} reps`));
      row.addEventListener("click", () => startTracking(key, () => showProgramDisplay(goalName, daysPerWeek)));
      listBox.appendChild(row);
    });
  }
  prevBtn.addEventListener("click", () => { if (dayIdx > 0) { dayIdx--; render(); } });
  nextBtn.addEventListener("click", () => { if (dayIdx < program.length - 1) { dayIdx++; render(); } });
  render();
}

// ---- Screen: My Own Schedule - day list ----
function showMySchedule() {
  clearRoot();
  const sched = loadMySchedule();
  const c = el("div", "screen");
  header(c, "MY SCHEDULE", "Your own training days");

  const list = el("div", "list-col");
  sched.days.forEach((day, idx) => {
    const row = el("div", "list-row list-row-click");
    row.appendChild(el("div", "list-row-title", day.name));
    row.appendChild(el("div", "list-row-sub", `${day.exercises.length} exercise${day.exercises.length !== 1 ? "s" : ""}`));
    row.addEventListener("click", () => showScheduleDay(idx));
    list.appendChild(row);
  });
  if (sched.days.length === 0) {
    c.appendChild(el("div", "note", "No days yet - add one below to start building your schedule."));
  }
  c.appendChild(list);

  const addBtn = el("button", "start-btn schedule-add-btn", "+ Add a day");
  addBtn.addEventListener("click", () => {
    sched.days.push({ name: `Day ${sched.days.length + 1}`, exercises: [] });
    saveMySchedule(sched);
    showMySchedule();
  });
  c.appendChild(addBtn);

  const backCard = card("Menu", "#2a2a2a", ICONS.back, showScheduleHub);
  backCard.classList.add("back-card", "single-back");
  c.appendChild(backCard);
  root.appendChild(c);
}

// ---- Screen: My Own Schedule - one day's detail ----
function showScheduleDay(dayIdx) {
  clearRoot();
  const sched = loadMySchedule();
  const day = sched.days[dayIdx];
  let searchText = "";

  const c = el("div", "screen");
  header(c, day.name.toUpperCase(), "Search to add exercises");

  const searchWrap = el("div", "nut-search-wrap");
  const searchInput = el("input", "nut-search-input");
  searchInput.type = "text";
  searchInput.placeholder = "Search exercises to add...";
  searchWrap.appendChild(searchInput);
  c.appendChild(searchWrap);
  const resultsBox = el("div", "nut-results");
  c.appendChild(resultsBox);

  c.appendChild(el("div", "logged-header", `${day.name} (${day.exercises.length})`));
  const entriesBox = el("div", "nut-entries");
  c.appendChild(entriesBox);

  function renderEntries() {
    entriesBox.innerHTML = "";
    if (day.exercises.length === 0) {
      entriesBox.appendChild(el("div", "note", "No exercises yet - search above to add some."));
    }
    day.exercises.forEach((exKey, idx) => {
      const ex = EXERCISES[exKey];
      if (!ex) return;
      const row = el("div", "nut-entry nut-entry-click");
      const info = el("div", "nut-entry-info");
      info.innerHTML = `<b>${ex.name}</b><br><span class="nut-entry-macros">${ex.group}</span>`;
      info.addEventListener("click", () => startTracking(exKey, () => showScheduleDay(dayIdx)));
      const removeBtn = el("button", "nut-remove-btn", "\u2715");
      removeBtn.addEventListener("click", () => {
        day.exercises.splice(idx, 1);
        saveMySchedule(sched);
        renderEntries();
      });
      row.appendChild(info);
      row.appendChild(removeBtn);
      entriesBox.appendChild(row);
    });
  }

  function renderResults() {
    resultsBox.innerHTML = "";
    const text = searchText.trim().toLowerCase();
    if (!text) return;
    Object.entries(EXERCISES)
      .filter(([, ex]) => ex.name.toLowerCase().includes(text))
      .slice(0, 6)
      .forEach(([key, ex]) => {
        const row = el("div", "nut-result");
        const dot = el("span", "nut-dot");
        dot.style.background = GROUP_COLORS[ex.group] || SPORT_COLORS[ex.group] || ACCENT;
        row.appendChild(dot);
        row.appendChild(el("span", null, `${ex.name} - ${ex.group}`));
        row.addEventListener("click", () => {
          day.exercises.push(key);
          saveMySchedule(sched);
          searchInput.value = ""; searchText = "";
          renderResults();
          renderEntries();
        });
        resultsBox.appendChild(row);
      });
  }
  searchInput.addEventListener("input", () => { searchText = searchInput.value; renderResults(); });

  const deleteBtn = el("button", "start-btn schedule-delete-btn", "Delete this day");
  deleteBtn.addEventListener("click", () => {
    sched.days.splice(dayIdx, 1);
    saveMySchedule(sched);
    showMySchedule();
  });
  c.appendChild(deleteBtn);

  const backCard = card("Back", "#2a2a2a", ICONS.back, showMySchedule);
  backCard.classList.add("back-card", "single-back");
  c.appendChild(backCard);
  root.appendChild(c);

  renderEntries();
  renderResults();
}

// ---- Screen: log the weight for this set (skippable) ----
function showWeightEntry(exercise, points, onDone) {
  clearRoot();
  const prevBest = points.exerciseBests[exercise.name] || 0;
  let weight = prevBest;

  const c = el("div", "screen");
  header(c, exercise.name.toUpperCase(), "What weight are you using?");

  const stepper = el("div", "weight-stepper");
  const minusBtn = el("button", "weight-step-btn", "\u2212");
  const valueBox = el("div", "weight-value", String(weight));
  const plusBtn = el("button", "weight-step-btn", "+");
  stepper.appendChild(minusBtn); stepper.appendChild(valueBox); stepper.appendChild(plusBtn);
  c.appendChild(stepper);

  if (prevBest) c.appendChild(el("div", "note", `Your best: ${prevBest}`));

  minusBtn.addEventListener("click", () => { weight = Math.max(0, weight - 2.5); valueBox.textContent = String(weight); });
  plusBtn.addEventListener("click", () => { weight = weight + 2.5; valueBox.textContent = String(weight); });

  const startBtn = el("button", "start-btn", "Start tracking");
  startBtn.addEventListener("click", () => onDone(weight));
  c.appendChild(startBtn);

  const skipBtn = el("button", "start-btn schedule-add-btn", "Skip (bodyweight)");
  skipBtn.addEventListener("click", () => onDone(0));
  c.appendChild(skipBtn);

  root.appendChild(c);
}

// ---- Screen: points earned after a set ----
function showPointsSummary(pts, totalPoints, isPr, streak, onContinue) {
  clearRoot();
  const c = el("div", "screen points-summary");
  if (isPr) c.appendChild(el("div", "pr-badge", "NEW PERSONAL RECORD!"));
  c.appendChild(el("div", "points-earned", `+${pts} points`));
  c.appendChild(el("div", "points-total", `Total: ${totalPoints} points`));
  if (streak > 1) c.appendChild(el("div", "note", `${streak}-day login streak`));
  const continueBtn = el("button", "start-btn", "Continue");
  continueBtn.addEventListener("click", onContinue);
  c.appendChild(continueBtn);
  root.appendChild(c);
}

async function startTracking(exerciseKey, returnFn) {
  const exercise = EXERCISES[exerciseKey];
  const goBack = returnFn || (() => showExerciseList(currentGroup, currentBackFn));
  if (exercise.type === "compound" || exercise.type === "isolation") {
    showWeightEntry(exercise, pointsData, (weight) => runTracking(exerciseKey, weight, goBack));
  } else {
    runTracking(exerciseKey, 0, goBack);
  }
}

async function runTracking(exerciseKey, weight, goBack) {
  const exercise = EXERCISES[exerciseKey];
  clearRoot();

  const c = el("div", "screen tracking-screen");
  const wrap = el("div", "video-wrap");

  const video = el("video");
  video.autoplay = true;
  video.playsInline = true;
  video.muted = true;
  const canvas = el("canvas");
  wrap.appendChild(video);
  wrap.appendChild(canvas);
  c.appendChild(wrap);

  const statusMsg = el("div", "loading-msg", "Requesting camera access...");
  c.appendChild(statusMsg);
  root.appendChild(c);

  try {
    stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: "user" }, audio: false });
  } catch (err) {
    statusMsg.textContent = "Couldn't access the camera. Check your browser's camera permission for this page.";
    return;
  }
  video.srcObject = stream;
  await new Promise((resolve) => { video.onloadedmetadata = resolve; });
  video.play();

  canvas.width = video.videoWidth;
  canvas.height = video.videoHeight;
  const ctx = canvas.getContext("2d");

  let cssW = 0, cssH = 0, dpr = 1;
  function sizeCanvasToViewport() {
    dpr = window.devicePixelRatio || 1;
    cssW = wrap.clientWidth;
    cssH = wrap.clientHeight;
    canvas.width = Math.round(cssW * dpr);
    canvas.height = Math.round(cssH * dpr);
  }
  sizeCanvasToViewport();
  window.addEventListener("resize", sizeCanvasToViewport);

  if (!poseLandmarker) {
    statusMsg.textContent = "Loading the AI model (first time only, then it's cached)...";
    const vision = await FilesetResolver.forVisionTasks(
      "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14/wasm"
    );
    poseLandmarker = await PoseLandmarker.createFromOptions(vision, {
      baseOptions: {
        modelAssetPath:
          "https://storage.googleapis.com/mediapipe-models/pose_landmarker/pose_landmarker_lite/float16/1/pose_landmarker_lite.task",
      },
      runningMode: "VIDEO",
      numPoses: 1,
    });
  }
  statusMsg.remove();

  let repCount = 0;
  let state = "up";
  let angleHistory = [];
  let secHistory = [];
  const SMOOTHING = 5;
  let lastTipText = null;
  let lastTipTime = 0;
  const MIN_TIP_SECONDS = 2500;

  function drawHUD(angle, feedback, feedbackColor, secText, tipText, tipGood) {
    const w = cssW, h = cssH;
    ctx.save();
    ctx.textBaseline = "alphabetic";

    ctx.fillStyle = "rgba(18,18,18,0.82)";
    ctx.fillRect(0, 0, w, 46);
    ctx.strokeStyle = ACCENT;
    ctx.lineWidth = 2.5;
    ctx.beginPath(); ctx.moveTo(0, 46); ctx.lineTo(w, 46); ctx.stroke();
    ctx.fillStyle = "#f0f0f0";
    ctx.font = "bold 17px 'Trebuchet MS', sans-serif";
    ctx.fillText(exercise.name.toUpperCase(), 14, 30);

    const repsText = `REPS ${String(repCount).padStart(2, "0")}`;
    ctx.font = "bold 16px 'Trebuchet MS', sans-serif";
    const repsW = ctx.measureText(repsText).width;
    ctx.strokeStyle = ACCENT; ctx.lineWidth = 2;
    ctx.strokeRect(w - repsW - 30, 8, repsW + 18, 30);
    ctx.fillStyle = ACCENT;
    ctx.fillText(repsText, w - repsW - 22, 29);

    if (feedback || angle !== null) {
      const rowY = 52, rowH = 30;
      ctx.fillStyle = "rgba(18,18,18,0.68)";
      ctx.fillRect(0, rowY, w, rowH);
      if (feedback) {
        ctx.font = "bold 15px 'Trebuchet MS', sans-serif";
        ctx.fillStyle = feedbackColor;
        ctx.fillText(feedback, 14, rowY + 21);
      }
      if (angle !== null) {
        const angleText = `${Math.round(angle)}\u00b0`;
        ctx.font = "bold 15px 'Trebuchet MS', sans-serif";
        const aw = ctx.measureText(angleText).width;
        ctx.fillStyle = ACCENT;
        ctx.fillText(angleText, w - aw - 14, rowY + 21);
      }
    }

    if (tipText) {
      const barY = h - 54;
      ctx.fillStyle = "rgba(18,18,18,0.85)";
      ctx.fillRect(0, barY, w, 46);
      ctx.fillStyle = tipGood ? "#22c55e" : "#f59e0b";
      ctx.fillRect(0, barY, 5, 46);
      ctx.font = "bold 14px 'Trebuchet MS', sans-serif";
      ctx.fillStyle = tipGood ? "#22c55e" : "#f59e0b";
      const label = tipGood ? "FORM:" : "TIP:";
      ctx.fillText(label, 16, barY + 28);
      const labelW = ctx.measureText(label).width;
      ctx.fillStyle = "#e5e5e5";
      ctx.font = "13px 'Trebuchet MS', sans-serif";
      ctx.fillText(tipText, 16 + labelW + 12, barY + 28);
    }

    ctx.restore();
  }

  function drawSkeleton(landmarks) {
    const conns = [
      [11, 12], [11, 13], [13, 15], [12, 14], [14, 16],
      [11, 23], [12, 24], [23, 24],
      [23, 25], [25, 27], [24, 26], [26, 28],
      [27, 31], [28, 32],
    ];
    ctx.save();
    ctx.strokeStyle = "#e0e0e0";
    ctx.lineWidth = 3;
    conns.forEach(([a, b]) => {
      const pa = landmarks[a], pb = landmarks[b];
      if (!pa || !pb) return;
      ctx.beginPath();
      ctx.moveTo(pa.x, pa.y);
      ctx.lineTo(pb.x, pb.y);
      ctx.stroke();
    });
    ctx.restore();
  }

  function frameLoop() {
    if (!stream) return;
    const now = performance.now();
    const result = poseLandmarker.detectForVideo(video, now);

    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, cssW, cssH);

    const videoW = video.videoWidth, videoH = video.videoHeight;
    const coverScale = Math.max(cssW / videoW, cssH / videoH);
    const drawW = videoW * coverScale, drawH = videoH * coverScale;
    const offsetX = (cssW - drawW) / 2, offsetY = (cssH - drawH) / 2;

    function videoToCanvas(nx, ny) {
      const px = nx * videoW * coverScale + offsetX;
      const py = ny * videoH * coverScale + offsetY;
      return { x: cssW - px, y: py };
    }

    ctx.save();
    ctx.translate(cssW, 0);
    ctx.scale(-1, 1);
    ctx.drawImage(video, offsetX, offsetY, drawW, drawH);
    ctx.restore();

    let angle = null, feedback = null, feedbackColor = ACCENT, secText = null;
    let tipText = null, tipGood = true;

    if (result.landmarks && result.landmarks.length > 0) {
      const raw = result.landmarks[0];
      const landmarks = raw.map((p) => {
        const { x, y } = videoToCanvas(p.x, p.y);
        return { x, y, visibility: p.visibility };
      });

      drawSkeleton(landmarks);

      const [ja, jb, jc] = sideJoints(exercise, "LEFT");
      const [jar, jbr, jcr] = sideJoints(exercise, "RIGHT");
      const aL = landmarks[ja], bL = landmarks[jb], cL = landmarks[jc];
      const aR = landmarks[jar], bR = landmarks[jbr], cR = landmarks[jcr];
      const visL = Math.min(aL?.visibility ?? 0, bL?.visibility ?? 0, cL?.visibility ?? 0);
      const visR = Math.min(aR?.visibility ?? 0, bR?.visibility ?? 0, cR?.visibility ?? 0);
      const usingLeft = visL >= visR;
      const [a, b, cc] = usingLeft ? [aL, bL, cL] : [aR, bR, cR];
      const minVis = usingLeft ? visL : visR;

      if (minVis > 0.4) {
        const rawAngle = calcAngle(a, b, cc);
        angleHistory.push(rawAngle);
        if (angleHistory.length > SMOOTHING) angleHistory.shift();
        angle = angleHistory.reduce((s, v) => s + v, 0) / angleHistory.length;

        if (angle < exercise.down && state === "up") state = "down";
        else if (angle > exercise.up && state === "down") { state = "up"; repCount++; }

        if (angle < exercise.down) { feedback = exercise.downLabel; feedbackColor = "#7ee787"; }
        else if (angle < exercise.up) { feedback = exercise.midLabel; feedbackColor = "#f0b429"; }
        else { feedback = exercise.upLabel; feedbackColor = "#e5e5e5"; }

        if (exercise.secJoints) {
          const [sa, sb, sc] = usingLeft
            ? sideJoints({ joints: exercise.secJoints }, "LEFT")
            : sideJoints({ joints: exercise.secJoints }, "RIGHT");
          const spa = landmarks[sa], spb = landmarks[sb], spc = landmarks[sc];
          const sVis = Math.min(spa?.visibility ?? 0, spb?.visibility ?? 0, spc?.visibility ?? 0);
          if (sVis > 0.4) {
            const secRaw = calcAngle(spa, spb, spc);
            secHistory.push(secRaw);
            if (secHistory.length > SMOOTHING) secHistory.shift();
            const secAngle = secHistory.reduce((s, v) => s + v, 0) / secHistory.length;
            secText = `${exercise.secLabel}: ${Math.round(secAngle)} deg`;
            const [tip, good] = getFormTip(exercise.secLabel, secAngle);
            tipText = tip; tipGood = good;
          } else if (exercise.framing === "upper_body") {
            tipText = `Reps: keep your ${exercise.joints[1].toLowerCase()} moving smoothly through the full range`;
            tipGood = true;
          } else {
            tipText = "Step back so more of your body is visible for a form check";
            tipGood = false;
          }
        } else {
          tipText = `Reps: keep your ${exercise.joints[1].toLowerCase()} moving smoothly through the full range`;
          tipGood = true;
        }
      } else {
        feedback = "JOINT NOT CLEARLY VISIBLE"; feedbackColor = "#f59e0b";
      }
    } else {
      feedback = "NO PERSON DETECTED"; feedbackColor = "#ef4444";
    }

    if (tipText && (lastTipText === null || now - lastTipTime >= MIN_TIP_SECONDS)) {
      if (tipText !== lastTipText) { lastTipText = tipText; lastTipTime = now; }
    }

    drawHUD(angle, feedback, feedbackColor, secText, lastTipText, tipGood);

    trackingLoopId = requestAnimationFrame(frameLoop);
  }

  const menuBtn = el("button", "menu-btn", "Menu");
  menuBtn.addEventListener("click", () => {
    const { pts, isPr } = computeAndApplyPoints(exercise, repCount, weight, pointsData);
    if (pts > 0) {
      showPointsSummary(pts, pointsData.totalPoints, isPr, pointsData.loginStreak, goBack);
    } else {
      goBack();
    }
  });
  c.appendChild(menuBtn);

  frameLoop();
}

pointsData = loadPoints();
applyDailyLoginBonus(pointsData);
showWelcome();
